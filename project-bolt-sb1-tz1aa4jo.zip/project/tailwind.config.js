module.exports = {
  content: [
    "./src/**/*.{html,js,ts,jsx,tsx}",
    "app/**/*.{ts,tsx}",
    "components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        backgroundblanc: "var(--backgroundblanc)",
        backgroundlight: "var(--backgroundlight)",
        "basicgrey-1": "var(--basicgrey-1)",
        blanc: "var(--blanc)",
        boutonsdefaut: "var(--boutonsdefaut)",
        "charactertitle-85": "var(--charactertitle-85)",
        conditionaldivider: "var(--conditionaldivider)",
        "couleurs-de-la-marque-1": "var(--couleurs-de-la-marque-1)",
        "primary-colorsbasedark": "var(--primary-colorsbasedark)",
        textesblanc: "var(--textesblanc)",
        textesdisabled: "var(--textesdisabled)",
        texteserreur: "var(--texteserreur)",
        textesprincipal: "var(--textesprincipal)",
        "x-151515": "var(--x-151515)",
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      fontFamily: {
        "body-regular": "var(--body-regular-font-family)",
        "open-sans-texte-courant-14-regular":
          "var(--open-sans-texte-courant-14-regular-font-family)",
        "tableau-raison-sociale": "var(--tableau-raison-sociale-font-family)",
        "tableau-texte": "var(--tableau-texte-font-family)",
        "TEXTES-s-regular-14": "var(--TEXTES-s-regular-14-font-family)",
        sans: [
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
          '"Apple Color Emoji"',
          '"Segoe UI Emoji"',
          '"Segoe UI Symbol"',
          '"Noto Color Emoji"',
        ],
      },
      boxShadow: { "shadow-03": "var(--shadow-03)" },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
    container: { center: true, padding: "2rem", screens: { "2xl": "1400px" } },
  },
  plugins: [],
  darkMode: ["class"],
};
