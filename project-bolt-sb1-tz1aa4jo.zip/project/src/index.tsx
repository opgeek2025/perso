import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { TableauDeBord } from "./screens/TableauDeBord/TableauDeBord";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <TableauDeBord />
  </StrictMode>,
);
