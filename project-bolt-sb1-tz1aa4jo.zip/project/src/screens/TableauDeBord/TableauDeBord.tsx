import React from "react";
import { DataSummarySection } from "./sections/DataSummarySection/DataSummarySection";
import { OverviewSection } from "./sections/OverviewSection";
import { RankingSection } from "./sections/RankingSection";

export const TableauDeBord = (): JSX.Element => {
  return (
    <main className="flex flex-col w-full min-h-screen bg-white">
      <div className="container mx-auto px-4 py-6 space-y-6">
        <RankingSection />
        <DataSummarySection />
        <OverviewSection />
      </div>
    </main>
  );
};
