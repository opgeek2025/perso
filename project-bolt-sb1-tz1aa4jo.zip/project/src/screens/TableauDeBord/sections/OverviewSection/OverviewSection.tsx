import React from "react";
import { Separator } from "../../../../components/ui/separator";

export const OverviewSection = (): JSX.Element => {
  // Footer links data for easy mapping
  const footerLinks = [
    { text: "Protection des données" },
    { text: "Politique cookies" },
    { text: "Mentions Légales" },
  ];

  return (
    <footer className="flex h-[102px] items-center justify-between px-[30px] py-0 w-full bg-white border-t-4 border-[#008859]">
      {/* Logo and tagline section */}
      <div className="flex items-center gap-[21px]">
        <div className="flex w-[161px] h-[60px] items-center">
          <div className="flex flex-col items-center justify-center">
            <div className="relative w-[161.5px] h-[34px]">
              <div className="absolute w-[34px] h-[34px] top-0 left-0 bg-[url(public/vector-13.svg)] bg-[100%_100%]">
                <div className="relative w-[33px] h-8 top-px left-px bg-[url(public/vector-12.svg)] bg-[100%_100%]">
                  <div className="relative w-[27px] h-[26px] top-[3px] left-[3px] bg-[url(public/group.png)] bg-[100%_100%]">
                    <img
                      className="absolute w-[27px] h-[26px] top-0 left-0"
                      alt="BNP Paribas Logo"
                      src="public/group-1.png"
                    />
                  </div>
                </div>
              </div>

              <div className="absolute w-[117px] h-[13px] top-[11px] left-11">
                <img
                  className="absolute w-[117px] h-3 top-0 left-0"
                  alt="BNP Paribas"
                  src="public/group-2.png"
                />
              </div>
            </div>
          </div>
        </div>

        <p className="font-normal text-x-151515 text-sm leading-[18px] whitespace-nowrap">
          La banque d&apos;un monde qui change
        </p>
      </div>

      {/* Footer links section */}
      <nav className="flex h-[51px] items-center">
        {footerLinks.map((link, index) => (
          <React.Fragment key={index}>
            {index > 0 && (
              <Separator orientation="vertical" className="h-[15px]" />
            )}

            <div className="flex flex-col h-[15px] items-center justify-center">
              <div className="flex flex-col items-start px-[15px] py-0 flex-1 mt-[-2px]">
                <a
                  href="#"
                  className="font-normal text-x-151515 text-sm leading-[18px] whitespace-nowrap mt-[-1px] mb-[-16px] hover:underline"
                >
                  {link.text}
                </a>
              </div>
              <div className="self-stretch w-full h-1 mb-[-3px]" />
            </div>

            {index < footerLinks.length - 1 && (
              <Separator orientation="vertical" className="h-[15px]" />
            )}
          </React.Fragment>
        ))}
      </nav>
    </footer>
  );
};
