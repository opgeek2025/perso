import {
  ArrowDownIcon,
  ArrowRightIcon,
  ArrowUpIcon,
  DownloadIcon,
} from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../../components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../../../components/ui/table";
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "../../../../components/ui/tabs";

// Data for the global overview table
const globalOverviewData = [
  {
    label: "Nombres d'Entreprises clientes",
    assuranceCollective: {
      value: "77",
      variation: "0.00 %",
      direction: "stable",
    },
    epargneSalariale: { value: "5", variation: "0.00 %", direction: "stable" },
    total: { value: "82", variation: "0.00 %", direction: "stable" },
  },
  {
    label: "Nombre de prospects",
    assuranceCollective: { value: "3", variation: null, direction: null },
    epargneSalariale: { value: "5", variation: null, direction: null },
    total: { value: "8", variation: null, direction: null },
  },
  {
    label: "Nombre de contrats",
    assuranceCollective: {
      value: "91",
      variation: "-0.30 %",
      direction: "down",
    },
    epargneSalariale: { value: "5", variation: "-0.12 %", direction: "down" },
    total: { value: "96", variation: "-0.12 %", direction: "down" },
  },
  {
    label: "Encours global",
    assuranceCollective: {
      value: "77 103 750 €",
      variation: "0.36 %",
      direction: "up",
    },
    epargneSalariale: {
      value: "769 609 €",
      variation: "1.44 %",
      direction: "up",
    },
    total: { value: "77 873 359 €", variation: "0.36 %", direction: "up" },
  },
  {
    label: "Collecte depuis le 01 janv.",
    assuranceCollective: {
      value: "3 222 679 €",
      variation: "20.98 %",
      direction: "up",
    },
    epargneSalariale: {
      value: "92 281 €",
      variation: "12.41 %",
      direction: "up",
    },
    total: { value: "33 14 960 €", variation: "20.80 %", direction: "up" },
  },
  {
    label: "Nombre de Versements Volont.",
    assuranceCollective: {
      value: "4 854",
      variation: "0.00 %",
      direction: "stable",
    },
    epargneSalariale: {
      value: "1 689",
      variation: "0.00 %",
      direction: "stable",
    },
    total: { value: "6 243", variation: "0.00 %", direction: "stable" },
  },
  {
    label: "Rétrocessions",
    assuranceCollective: { value: "4 854", variation: null, direction: null },
    epargneSalariale: { value: "1 689", variation: null, direction: null },
    total: { value: "6 243", variation: null, direction: null },
  },
  {
    label: "Commissions",
    assuranceCollective: { value: "N/A", variation: null, direction: null },
    epargneSalariale: { value: "25 764 €", variation: null, direction: null },
    total: { value: "25 764 €", variation: null, direction: null },
  },
];

// Data for the ranking table
const rankingData = [
  { name: "NOM DU GROUPE", product: "Art 83", amount: "XX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "Art 83", amount: "XX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "PERECO", amount: "XX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "PEE", amount: "XX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "Art 83", amount: "XX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "Art 83", amount: "XXX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "PERO", amount: "XX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "Art 83", amount: "X XXX,XX €" },
  { name: "NOM DU GROUPE", product: "PEE", amount: "XXX XXX,XX €" },
  { name: "NOM DU GROUPE", product: "Art 83", amount: "X XXX,XX €" },
  { name: "NOM DU GROUPE", product: "Art 83", amount: "X XXX,XX €" },
];

const months = [
  "Janvier",
  "Février",
  "Mars",
  "Avril",
  "Mai",
  "Juin",
  "Juillet",
  "Août",
  "Septembre",
  "Octobre",
  "Novembre",
  "Décembre",
];

export const DataSummarySection = (): JSX.Element => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth();
  
  return (
    <section className="flex flex-col gap-[30px] p-5 bg-[#e0e0e0] w-full">
      <div className="flex flex-col gap-5 w-full">
        <div className="text-[#0e0e0e] text-[10px] [font-family:'BNPP_Sans-Light',Helvetica] font-light">
          Données mises à jour le XX.XX.XX à XXhXX
        </div>

        <div className="flex justify-between items-center w-full">
          <Select defaultValue={`${months[currentMonth]} ${currentYear}`}>
            <SelectTrigger className="w-[250px] h-12 bg-blanc rounded-[3px] border-[#e1e0e0] [font-family:'BNPP_Sans-Light',Helvetica]">
              <span className="flex items-center gap-[5px]">
                <span className="font-light">Janvier à :</span>
                <span className="font-normal text-[#1f1f1f]">
                  {months[currentMonth]} {currentYear}
                </span>
              </span>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {months.map((month) => (
                <SelectItem key={month} value={`${month} ${currentYear}`}>
                  {month} {currentYear}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button className="h-12 bg-boutonsdefaut rounded-[3px] text-blanc gap-2.5 hover:bg-[#006e3d] transition-colors">
            <DownloadIcon className="w-6 h-6" />
            <span className="font-TEXTES-s-regular-14">Télécharger</span>
          </Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-10 w-full">
        {/* Global Overview Card */}
        <Card className="flex-1 min-w-0 lg:w-[615px] bg-white">
          <CardHeader className="px-5 pt-[30px] pb-5 flex items-center justify-between">
            <CardTitle className="text-[22px] font-bold [font-family:'BNPP_Sans-Bold',Helvetica] text-black">
              Apercu global
            </CardTitle>
            <Button className="h-12 bg-boutonsdefaut rounded-[3px] text-blanc gap-2.5 hover:bg-[#006e3d] transition-colors lg:hidden">
              <DownloadIcon className="w-6 h-6" />
              <span className="font-TEXTES-s-regular-14">Télécharger</span>
            </Button>
          </CardHeader>
          <CardContent className="px-5 pb-[30px] overflow-x-auto">
            <div className="min-w-[800px]">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[#6f6f6f] h-14">
                    <TableHead className="w-[214px] text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Indicateurs</div>
                    </TableHead>
                    <TableHead className="text-right text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Assurance Collective</div>
                    </TableHead>
                    <TableHead className="text-right text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Epargne Salariale</div>
                    </TableHead>
                    <TableHead className="text-right text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Total</div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {globalOverviewData.map((row, index) => (
                    <TableRow
                      key={index}
                      className={index % 2 === 0 ? "bg-white" : "bg-[#f8f8f8]"}
                    >
                      <TableCell className="font-tableau-texte text-textesprincipal">
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold">{row.label}</span>
                          {row.assuranceCollective.variation && (
                            <span className="text-xs [font-family:'BNPP_Sans-Light',Helvetica] font-light">
                              Variation sur l'année en cours
                            </span>
                          )}
                        </div>
                      </TableCell>

                      <TableCell className="text-right">
                        <div className="flex flex-col">
                          <span
                            className={`text-sm font-semibold ${index < 3 ? "text-charactertitle-85" : "text-textesprincipal"}`}
                          >
                            {row.assuranceCollective.value}
                          </span>
                          {row.assuranceCollective.variation && (
                            <div className="flex items-center justify-end gap-1">
                              <span className="text-xs [font-family:'BNPP_Sans-Light',Helvetica] font-light text-textesprincipal">
                                {row.assuranceCollective.variation}
                              </span>
                              {row.assuranceCollective.direction === "up" && (
                                <ArrowUpIcon className="w-[8.67px] h-[13px] text-[#00915a]" />
                              )}
                              {row.assuranceCollective.direction === "down" && (
                                <ArrowDownIcon className="w-[8.67px] h-[13px] text-[#ba4057]" />
                              )}
                              {row.assuranceCollective.direction === "stable" && (
                                <ArrowRightIcon className="w-[13px] h-[8.67px] text-[#686767]" />
                              )}
                            </div>
                          )}
                        </div>
                      </TableCell>

                      <TableCell className="text-right">
                        <div className="flex flex-col">
                          <span
                            className={`text-sm font-semibold ${index < 3 ? "text-charactertitle-85" : "text-textesprincipal"}`}
                          >
                            {row.epargneSalariale.value}
                          </span>
                          {row.epargneSalariale.variation && (
                            <div className="flex items-center justify-end gap-1">
                              <span className="text-xs [font-family:'BNPP_Sans-Light',Helvetica] font-light text-textesprincipal">
                                {row.epargneSalariale.variation}
                              </span>
                              {row.epargneSalariale.direction === "up" && (
                                <ArrowUpIcon className="w-[8.67px] h-[13px] text-[#00915a]" />
                              )}
                              {row.epargneSalariale.direction === "down" && (
                                <ArrowDownIcon className="w-[8.67px] h-[13px] text-[#ba4057]" />
                              )}
                              {row.epargneSalariale.direction === "stable" && (
                                <ArrowRightIcon className="w-[13px] h-[8.67px] text-[#686767]" />
                              )}
                            </div>
                          )}
                        </div>
                      </TableCell>

                      <TableCell
                        className={`text-right ${index % 2 === 0 ? "bg-[#e6f3ee]" : "bg-[#d9ede6]"} border-r border-[#0000000f]`}
                      >
                        <div className="flex flex-col">
                          <span
                            className={`text-sm font-semibold ${index < 3 ? "text-charactertitle-85" : "text-textesprincipal"}`}
                          >
                            {row.total.value}
                          </span>
                          {row.total.variation && (
                            <div className="flex items-center justify-end gap-1">
                              <span className="text-xs [font-family:'BNPP_Sans-Light',Helvetica] font-light text-textesprincipal">
                                {row.total.variation}
                              </span>
                              {row.total.direction === "up" && (
                                <ArrowUpIcon className="w-[8.67px] h-[13px] text-[#00915a]" />
                              )}
                              {row.total.direction === "down" && (
                                <ArrowDownIcon className="w-[8.67px] h-[13px] text-[#ba4057]" />
                              )}
                              {row.total.direction === "stable" && (
                                <ArrowRightIcon className="w-[13px] h-[8.67px] text-[#686767]" />
                              )}
                            </div>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Ranking Card */}
        <Card className="flex-1 min-w-0 lg:w-[585px] bg-white">
          <CardHeader className="px-5 pt-[30px] pb-5 flex flex-row justify-between items-center">
            <CardTitle className="text-[22px] font-bold [font-family:'BNPP_Sans-Bold',Helvetica] text-black">
              Classement
            </CardTitle>
            <Tabs defaultValue="encours" className="h-10">
              <TabsList className="bg-backgroundlight rounded-[5px]">
                <TabsTrigger
                  value="encours"
                  className="data-[state=active]:bg-backgroundblanc data-[state=active]:shadow-[0px_2px_3px_#00000026] rounded-[5px] px-[15px] py-[9px] text-sm"
                >
                  Top 10 des encours
                </TabsTrigger>
                <TabsTrigger
                  value="collectes"
                  className="rounded-[26px] px-[15px] py-3 text-sm [font-family:'BNPP_Sans-Light',Helvetica] font-light opacity-85"
                >
                  Top 10 des collectes
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          <CardContent className="px-5 pb-[30px] overflow-x-auto">
            <div className="min-w-[500px]">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[#6f6f6f] h-14">
                    <TableHead className="w-[310px] text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Raison sociale</div>
                    </TableHead>
                    <TableHead className="w-[115px] text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Produit</div>
                    </TableHead>
                    <TableHead className="text-right text-textesblanc cursor-pointer hover:bg-[#5f5f5f] transition-colors">
                      <div className="text-base font-semibold">Montant des encours</div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rankingData.map((row, index) => (
                    <TableRow
                      key={index}
                      className={index % 2 === 0 ? "bg-white" : "bg-[#f8f8f8]"}
                    >
                      <TableCell className="font-tableau-raison-sociale text-textesprincipal border-l border-[#0000000f]">
                        <span className="text-sm font-semibold">{row.name}</span>
                      </TableCell>
                      <TableCell>
                        <div className="inline-flex items-baseline justify-center px-[5px] py-1 bg-[#f9f9f9] border border-solid border-[#d9d9d9]">
                          <span className="text-xs font-medium text-[#0e0e0e]">
                            {row.product}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-tableau-texte text-textesprincipal border-r border-[#0000000f]">
                        <span className="text-sm font-semibold">{row.amount}</span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};