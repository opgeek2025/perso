import React from "react";
import { useNavigate } from "react-router-dom";

export const RankingSection = (): JSX.Element => {
  const navigate = useNavigate();
  
  // Navigation menu items data
  const navItems = [
    { label: "TABLEAU DE BORD", path: "/", active: true },
    { label: "PORTEFEUILLES CLIENTS", path: "/portefeuilles", active: false },
    { label: "COMISSIONS ET RETROCESSIONS", path: "/commissions", active: false },
  ];

  const handleNavClick = (path: string) => {
    navigate(path);
  };

  return (
    <div className="flex flex-col items-start gap-px relative self-stretch w-full">
      <header className="relative self-stretch w-full bg-white border-b border-[#e0e0e0]">
        <div className="flex items-center justify-between w-full h-[62px] bg-white border-t border-b border-[#e0e0e0]">
          {/* Logo section */}
          <div className="flex items-center h-[60px] pl-[29px]">
            <div className="flex flex-col items-center justify-center">
              <img
                className="w-[226px] h-[34px] object-cover"
                alt="Logo"
                src="public/logo.png"
              />
            </div>
          </div>

          {/* Middle section - intentionally empty */}
          <div className="flex-1" />

          {/* Contact link */}
          <div className="h-[60px] w-[130px] flex items-center justify-center border-x border-[#e0e0e0] cursor-pointer hover:bg-[#f5f5f5] transition-colors">
            <div className="font-tableau-texte text-sm text-x-151515">
              Contact
            </div>
          </div>

          {/* User profile section */}
          <div className="flex h-[60px]">
            <div className="w-[284px] h-full bg-[#3c8354] border-r border-[#e0e0e0] flex flex-col justify-center pl-5">
              <div className="font-tableau-texte font-normal text-white text-base leading-[20.6px]">
                Prénom Nom
              </div>
              <div className="font-tableau-texte font-normal text-textesblanc text-xs leading-[4.8px] mt-[5px]">
                Dernière connexion le 03.05.20224 à 9h000
              </div>
            </div>
            <div className="w-[61px] h-full bg-[#327047] flex items-center justify-center cursor-pointer hover:bg-[#2a5d3b] transition-colors">
              <img
                className="w-[21px] h-[19px]"
                alt="Union"
                src="public/union.svg"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation menu */}
      <nav className="flex items-center w-full bg-white border-b border-[#e0e0e0]">
        <div className="flex items-center gap-[15px] px-0 py-4 ml-[100px] relative">
          {navItems.map((item, index) => (
            <React.Fragment key={item.label}>
              <div
                onClick={() => handleNavClick(item.path)}
                className={`relative font-tableau-texte font-normal text-x-151515 text-sm leading-[18.0px] cursor-pointer hover:text-[#00915a] transition-colors ${
                  item.active ? "text-[#00915a]" : ""
                }`}
              >
                {item.label}
                {item.active && (
                  <div className="absolute w-full h-1 bottom-[-16px] left-0 bg-couleurs-de-la-marque-1" />
                )}
              </div>
              {index < navItems.length - 1 && (
                <img
                  className="w-px h-[15px] object-cover"
                  alt="Line"
                  src="public/line-104.svg"
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </nav>
    </div>
  );
};